require('dotenv').config();
const puppeteer = require('puppeteer');
const readline = require('readline');
const fs = require('fs');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function getRandomDelay(min = 1000, max = 1500) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

// Fungsi untuk membuat akun
async function createAccount(password = process.env.PASSWORD) {
    if (!password) {
        console.error('Password is not set. Please set the password in .env or provide it as an argument.');
        return;
    }

    const browser = await puppeteer.launch({ headless: false });
    const emailPage = await browser.newPage();
    const page = await browser.newPage();

    try {
        // Step 1: Dapatkan email dari generator.email
        await emailPage.goto('https://generator.email', { waitUntil: 'networkidle2' });
        await new Promise(resolve => setTimeout(resolve, getRandomDelay()));
        await emailPage.waitForSelector('#email_ch_text');
        const email = await emailPage.$eval('#email_ch_text', el => el.innerText);
        console.log(`Generated email: ${email}`);

        // Step 2: Buka halaman signup CapCut
        await page.goto('https://www.capcut.com/signup', { waitUntil: 'networkidle2' });
        await new Promise(resolve => setTimeout(resolve, getRandomDelay()));

        // Step 3: Isi email
        await page.waitForSelector('input[name="signUsername"]');
        await page.type('input[name="signUsername"]', email);
        await new Promise(resolve => setTimeout(resolve, getRandomDelay()));
        await page.click('button.lv-btn-primary');

        await page.waitForSelector('input[type="password"]');
        await page.type('input[type="password"]', password );

        await new Promise(resolve => setTimeout(resolve, getRandomDelay()));
        await page.click('button.lv-btn-primary.lv-btn-size-large');

        // Step 6: Isi tanggal lahir
        await page.waitForSelector('input[placeholder="Year"]');
        await page.type('input[placeholder="Year"]', '2000');

        // Fungsi untuk memilih dropdown berdasarkan teks di dalam <span>
        async function selectDropdownByText(page, dropdownLabel, optionText) {
            await page.evaluate((dropdownLabel) => {
                document.querySelectorAll('span.lv-select-view-value-mirror').forEach(span => {
                    if (span.innerText.trim() === dropdownLabel) {
                        span.click();
                    }
                });
            }, dropdownLabel);

            await page.waitForSelector('li[role="option"]');

            await page.evaluate((optionText) => {
                document.querySelectorAll('li[role="option"]').forEach(option => {
                    if (option.innerText.trim() === optionText) {
                        option.click();
                    }
                });
            }, optionText);
        }

        // Pilih bulan "May"
        await selectDropdownByText(page, 'Month', 'May');

        // Pilih tanggal "10"
        await selectDropdownByText(page, 'Day', '10');

        console.log('Birth date filled!');
        await page.waitForSelector('button[type="button"]', { visible: true });
        const buttons = await page.$$('button[type="button"]');
        await buttons[buttons.length - 1].click(); // Coba klik tombol terakhir

        console.log('Waiting for OTP...');
        await new Promise(resolve => setTimeout(resolve, getRandomDelay()));

        // Step 5: Ambil OTP
        let otp = null;
        for (let i = 0; i < 10; i++) {
            await new Promise(resolve => setTimeout(resolve, getRandomDelay(5000, 7000))); // Tunggu 5-7 detik
            try {
                await emailPage.reload({ waitUntil: 'networkidle2' });

                if (i >= 3) {
                    const refreshButton = await emailPage.$('button.btn.btn-success');
                    if (refreshButton) {
                        await refreshButton.click();
                        console.log('Clicked refresh button');
                        await new Promise(resolve => setTimeout(resolve, getRandomDelay(2000, 3000)));
                    }
                }

                const emails = await emailPage.evaluate(() => {
                    return Array.from(document.querySelectorAll('.e7m')).map(el => el.innerText);
                });

                for (const emailText of emails) {
                    if (emailText.includes('CapCut')) {
                        const otpMatch = emailText.match(/\b\d{6}\b/);
                        if (otpMatch) {
                            otp = otpMatch[0];
                            console.log(`OTP received: ${otp}`);
                            break;
                        }
                    }
                }

                if (otp) break;
            } catch (error) {
                console.log('Retrying OTP fetch...', error);
            }
        }

        if (!otp) {
            console.log('Failed to get OTP');
            return;
        }

        // Step 6: Masukkan OTP
        await page.waitForSelector('.verification_code_input-number');
        for (const digit of otp) {
            await page.keyboard.type(digit);
            await new Promise(resolve => setTimeout(resolve, getRandomDelay(200, 400)));
        }

        await new Promise(resolve => setTimeout(resolve, getRandomDelay()));
        await page.waitForSelector('button.lv-btn-primary.lv-btn-size-large');
        await page.click('button.lv-btn-primary.lv-btn-size-large');

        console.log('Account created successfully!');

        // Simpan email dan password ke file txt
        fs.appendFileSync('accounts.txt', `${email}:${password}\n`);
        console.log(`Account saved to accounts.txt: ${email}`);
    }  catch (error) {
        console.error('An error occurred:', error);
    } finally {
        await browser.close(); // Hanya tutup browser, tidak perlu tutup readline
    } // Hapus rl.close() di sini
}

function askQuestion(query) {
    return new Promise(resolve => rl.question(query, resolve));
}

async function main() {
    console.clear();
    const action = await askQuestion('== CAPCUT ACCOUNT CREATOR by WINTERS == \n1. Create 1 account \n2. Create multiple accounts \n3. Set password in .env \nYour Choice: ');
    if (action === '1') {
        // Cuma buat 1 akun tanpa minta password
        await createAccount();
    } else if (action === '2') {
        const count = await askQuestion('How many accounts would you like to create? ');
        const countNum = parseInt(count);
        for (let i = 0; i < countNum; i++) {
            console.log(`Creating account ${i + 1}/${countNum}...`);
            await createAccount();
            // Tambah delay antara akun
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
        
    } else if (action === '3') {
        const password = await askQuestion('Enter your new password (will be saved in .env): ');
        process.env.PASSWORD = 'password'; // Gunakan 'password', bukan 'PASSWORD' yang tidak dideklarasikan
        fs.writeFileSync('.env', `PASSWORD='${password}'\n`);
        console.log('Password has been updated in .env');        
    } else {
        console.log('Invalid option, please choose again.');
    }

    rl.close();
}

main();